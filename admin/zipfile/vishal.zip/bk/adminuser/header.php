
<?php
    error_reporting(0);
    include("session.php");
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>

<link rel="stylesheet" href="adminstyle.css" type="text/css">
<title>ADMIN PANEL</title>
</head>

<?php
error_reporting(0);
?>

<body>
<div class="header"><br /> Welcome To Our Site Admin panel

<div id="topmenu">
	<ul>
	
	<li><a  href="dashbord.php">Dashboard</a></li>
	<li><a  href="#">Home</a></li>
	<li><a  href="#">About us</a></li>
	<li><a  href="album_display.php">Album</a></li>
	<li><a  href="#">Services</a></li>
	<li><a  href="#">Contact us</a></li>
	<li><a  href="#">Slider</a></li>
	
	<li><a  href="news.php">News Update</a></li>
	<li><a  href="logout.php">Logout</a></li>
	</ul>
</div>
</div>
</body>
</html>