<div class="product_box">
	<div class="sidemenu">
	
	<div class="sideheader">
		<h3>&nbsp;&nbsp; Cms Details</h3>
	</div>
		<a href='cmsupdate.php'>&nbsp;&nbsp;+&nbsp;&nbsp;Update CMS Data&nbsp;&nbsp;</a><br><br>
		<a href='newpage.php'>&nbsp;&nbsp;+&nbsp;&nbsp;Add New Page&nbsp;&nbsp;</a><br><br>

		<a href='template.php'>&nbsp;&nbsp;+&nbsp;&nbsp;Template&nbsp;&nbsp;</a><br><br>
	
	

	</div>

<div class="productdata">