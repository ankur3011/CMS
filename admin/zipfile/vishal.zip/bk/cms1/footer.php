 <!-- footer -->          
			    <div id="ja-botsl" class="wrap ">
                	<div class="main">
                    	<div class="main-inner1 clearfix">
                        	<div style="height:200px; width:100%; border-bottom:2px solid powderblue;font-size:15px;">
								<div style="height:180px;float:left;width:200px;">
									<ul style="list-style:none;">
										
										
														  					
																	
									</ul>
								</div>
								<div style="height:180px;float:left;width:200px;">
									<ul style="list-style:none;">
										
										
								</div>
								<div style="height:180px;float:left;width:200px;">
									<ul style="list-style:none;">
										
														  						
									</ul>
								</div>
							
							</div>
							<div style="height:10px;"></div>
							
                        	<div class="ja-box column ja-box-center" style="width: 38%;">
                            	<div class="ja-moduletable moduletable  clearfix" id="Mod62">
                          			Copyrights © 2013 <br> All Rights Reserved
                				<div class="ja-box-ct clearfix"></div>
                            	</div>
                       		</div>
						
					
					
                        	<div class="ja-box column ja-box-center" style="width: 25%;">
                            	<div class="ja-moduletable moduletable  clearfix" id="Mod62">
                          			Total Visitor:
									<!--<img src="./itap_files/counter.php" border="0" alt="Visitor Counter">-->
									<img src="http://hitwebcounter.com/counter/counter.php?page=5757656&style=0010&nbdigits=7&type=page&initCount=136796" title="" Alt=""   border="0" >
									
   
 
                				<div class="ja-box-ct clearfix"></div>
                            	</div>	
							</div>
                       	
							
				
                        	<div class="ja-box column ja-box-center" style="width: 37%;">
                            	<div class="ja-moduletable moduletable  clearfix" id="Mod62">
                          			<a href="terms.php">Terms and Conditions</a>&nbsp;&nbsp;
									<a href="policy.php">Privacy Policy</a>
									
                				<div class="ja-box-ct clearfix"></div>
								</div>
                            </div>
				</div>
   </div>
</div>     

</body> 
</html>      