<!-- right column  -->	
				<div id="ja-mainbody" style="width: 72%">
                	<div id="ja-main" style="width: 100%">
                    	<div class="inner clearfix">
							<div id="ja-contentwrap" class="clearfix ja-ri">
        						<div id="ja-content" class="column" style="width: 100%">
            						<div id="ja-current-content" class="column" style="width: 100%">
                						<div id="ja-content-main" class="ja-content-main clearfix">
                    						<div class="blog-featured">
                        						<div class="items-row cols-1 row-0 clearfix">
                            						<div class="item column0">
                                						<div class="contentpaneopen clearfix">
                                        					
                                    					