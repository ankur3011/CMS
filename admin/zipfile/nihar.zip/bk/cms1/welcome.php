<?php
include("./dataconnection/config.php");
include 'mainhead.php';
include'uptoslider.php';
include'main_content_start.php';
include'rightcolumn.php';?>

<h1 class="componentheading">
user guidence<br>
</h1>
<?php


include'right_column_complete.php';
include'maincontentstop.php';
include'footer.php';


?>
