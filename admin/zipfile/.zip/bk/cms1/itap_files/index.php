<?php
header("Location:../home.php");
?>
