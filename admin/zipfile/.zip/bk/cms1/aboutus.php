<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">


<title>About us page </title>

</head>
</html>	
<?php
include 'mainhead.php';
include'uptoslider.php';
include'main_content_start.php';
include'rightcolumn.php';
 
{
  

?>
<p style="text-align: justify;">	
<pre style="text-align: justify;font-family:Arial, Helvetica, sans-serif;font-size:14px;color: #333;font-weight:500;">
</pre>
About CMS Website 

</p>	

<?php
}
include'right_column_complete.php';
include'maincontentstop.php';
include'footer.php';

?>
											