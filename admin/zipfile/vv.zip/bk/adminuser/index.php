<?php
header("Location:productlist.php");
?>
